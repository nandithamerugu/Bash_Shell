# ASSIGNMENT SHELL TEAM - 47

we have three main folder in this

```
project

assigment

user

```
# project

This folder contains the code.

# assignment

 This contains 
 
 ```
 |
 |__dist folder 
 |         | 
 |         |__submitter.py
 |
 |__assigment.pdf files
 |
 |__code.c etc files
 
```
# user

This is the user folder on which operations (switch ,create,submit etc) are done.

## i.txt 
contains indented tree structure for setup command.

# test case 
 use the files in this and replace some of the files in assignment folder to check for update command.
