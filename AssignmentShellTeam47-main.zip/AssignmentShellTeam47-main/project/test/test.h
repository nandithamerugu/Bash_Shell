#ifndef __TEST_H
#define __TEST_H

void Execute(PtrToDirec name,PtrToDirec dist_folder);
void test(char *input_string);
PtrToDirec FindFile(PtrToDirec root, char *file_name);

#endif