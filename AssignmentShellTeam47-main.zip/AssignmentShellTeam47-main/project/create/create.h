#ifndef __CREATE_H__
#define __CREATE_H__

void create(char *input_string);
void MakeNewFolder(char *input_string);
void copy_everything(char *destination);
void AddSlashSpaceInSubjectName(char *input_string);

#endif
