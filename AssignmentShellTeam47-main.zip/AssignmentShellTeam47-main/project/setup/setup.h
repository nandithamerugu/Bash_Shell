#ifndef __SETUP_H__
#define __SETUP_H__

void setup(char *file_path);
void make_dir_path(char *path, int spaces, char *new_dir_name);

#endif