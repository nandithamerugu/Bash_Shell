# switch

when you enter switch you should also enter name of the folder or subject you want to switch to.

```
user>switch dsa
user/dsa>

```
The prompt will change as above one.
If you use it again you will get the following

```
user>switch dsa
user/dsa>switch dsm
user/dsm>switch Linear Algebra
user/Linear Algebra>

```
**`Note :`** `Linear Algebra` needs to be `la` in short i.e.,the prompt shhould be  `user/la>`.