# USE

when you enter use you should also enter assignment name to which we want to move.

```
user>switch dsa
user/dsa>use assign-1
user/dsa/assign-1>

```
The prompt will change as above one.



