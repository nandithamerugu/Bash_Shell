#ifndef __USE_H__
#define __USE_H__

PtrToDirec NEW_CURR_PATH;

bool use(char *input_string);
void change_dir_back();

#endif
